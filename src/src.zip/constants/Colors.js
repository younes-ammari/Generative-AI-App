export default Colors = {
    primary:"rgb(57,45,126)",
    green:"#C3E6E2",
    bleu : "#0b67f5",
    lighter:'#FFF',
    darker:"#000",
    rgb:{
        primary:"57,45,126",

    }
}